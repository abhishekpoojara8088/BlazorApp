﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BANKIFSC_Shared.Authentication
{
    public static class ConnectionString
    {
        public static string SqlConnectionString = "Server=tcp:DESKTOP-A8K3B6E,49172;Database=BANKIFSC;User ID=testdemo;password=test@123;Integrated Security=False;Trusted_Connection=False;Encrypt=False;";
    }
}
