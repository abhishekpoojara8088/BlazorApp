﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BANKIFSC_Shared.Entity.LOC
{
    public class LOC_State
    {
        [Key] public int StateID { get; set; }
        [ForeignKey(nameof(LOC_Country.CountryID))] public int CountryID { get; set; }
        [Required] public string StateName { get; set; }
        public int CreatedByUserID { get; set; }
        public DateTime CreatedDate { get; set; }
        public int ModifiedByUserID { get; set; }
        public DateTime ModifiedDate { get; set; }
        public string? Remarks { get; set; }
        public bool IsDeleted { get; set; }
    }
}
