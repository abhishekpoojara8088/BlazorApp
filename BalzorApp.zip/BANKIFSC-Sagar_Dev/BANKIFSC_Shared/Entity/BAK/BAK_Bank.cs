﻿using Microsoft.AspNetCore.Components.Forms;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Internal;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BANKIFSC_Shared.Entity.BAK
{
    public class BAK_Bank 
    {
        [Key] public int BankID { get; set; }
        [Required(ErrorMessage = "Name is Required!")] public string BankName { get; set; }
        public string Address { get; set; }
        public string ContactNo { get; set; }
        public string FAX { get; set; }
        public string Website { get; set; }
        [EmailAddress] public string Email { get; set; }
        public string? ImageURL { get; set; }
        public int CreatedByUserID { get; set; }
        public DateTime CreatedDate { get; set; }
        public int ModifiedByUserID { get; set; }
        public DateTime ModifiedDate { get; set; }
        public string? Remarks { get; set; }
        public bool IsDeleted { get; set; }

    }
   
}

