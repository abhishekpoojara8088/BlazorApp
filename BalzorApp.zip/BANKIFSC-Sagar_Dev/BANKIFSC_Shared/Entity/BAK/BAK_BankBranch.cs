﻿using BANKIFSC_Shared.Entity.LOC;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BANKIFSC_Shared.Entity.BAK
{
    public class BAK_BankBranch
    {
        [Key] public int BranchID { get; set; }
        [ForeignKey(nameof(BAK_Bank.BankID))] public int BankID { get; set; }
        [ForeignKey(nameof(LOC_City.CityID))] public int CityID { get; set; }
        [Required(ErrorMessage = "Name is Required!")] public string BranchName { get; set; }
        public string IFSC { get; set; }
        public string Address { get; set; }
        public string ContactNo { get; set; }
        public string PIN { get; set; }
        public int CreatedByUserID { get; set; }
        public DateTime CreatedDate { get; set; }
        public int ModifiedByUserID { get; set; }
        public DateTime ModifiedDate { get; set; }
        public string? Remarks { get; set; }
        public bool IsDeleted { get; set; }
    }
}
