﻿using BANKIFSC_BAL.IBusinessLogic.Admin.SEC;
using BANKIFSC_DAL.IRepository.Admin.SEC;
using BANKIFSC_Shared.Entity.SEC;


namespace BANKIFSC_BAL.BusinessLogic.Admin.SEC
{
    public class SEC_UserBusiness : ISEC_UserBusiness
    {
        private readonly ISEC_UserRepository _sEC_UserRepository;

        public SEC_UserBusiness(ISEC_UserRepository sEC_UserRepository)
        {
            _sEC_UserRepository = sEC_UserRepository;
        }

        #region Select
        public async Task<List<SEC_User>> SelectAll()
        {
            try
            {
                return await _sEC_UserRepository.SelectAll();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion
    }
}
