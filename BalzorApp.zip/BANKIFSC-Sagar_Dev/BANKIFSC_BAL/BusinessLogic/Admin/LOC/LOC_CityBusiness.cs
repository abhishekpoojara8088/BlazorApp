﻿using BANKIFSC_BAL.IBusinessLogic.Admin.LOC;
using BANKIFSC_DAL.IRepository.Admin.LOC;
using BANKIFSC_Shared.Entity.LOC;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BANKIFSC_BAL.BusinessLogic.Admin.LOC
{
    public class LOC_CityBusiness : ILOC_CityBusiness
    {
        private readonly ILOC_CityRepository _lOC_CityRepository;

        public LOC_CityBusiness(ILOC_CityRepository lOC_CityRepository)
        {
            _lOC_CityRepository = lOC_CityRepository;
        }


        #region Insert
        public async Task Insert(int stateId, LOC_City lOC_City)
        {
            try
            {
                await _lOC_CityRepository.Insert(stateId, lOC_City);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion



        #region Update
        public async Task Update(LOC_City lOC_City)
        {
            try
            {
                await _lOC_CityRepository.Update(lOC_City);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion



        #region Delete
        public async Task Delete(int cityId)
        {
            try
            {
                await _lOC_CityRepository.Delete(cityId);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion



        #region Select
        public async Task<List<LOC_City>> SelectAll()
        {
            try
            {
                return await _lOC_CityRepository.SelectAll();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public async Task<List<LOC_City>> SelectByCityID(int cityId)
        {
            try
            {
                return await _lOC_CityRepository.SelectByCityID(cityId);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion
    }
}
