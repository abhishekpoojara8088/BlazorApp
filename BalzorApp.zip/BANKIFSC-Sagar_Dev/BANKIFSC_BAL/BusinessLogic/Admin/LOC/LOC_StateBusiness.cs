﻿using BANKIFSC_BAL.IBusinessLogic.Admin.LOC;
using BANKIFSC_DAL.IRepository.Admin.LOC;
using BANKIFSC_DAL.Repository.Admin.LOC;
using BANKIFSC_Shared.Entity.LOC;
using MaxMind.GeoIP2.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BANKIFSC_BAL.BusinessLogic.Admin.LOC
{
    public class LOC_StateBusiness : ILOC_StateBusiness
    {
        private readonly ILOC_StateRepository _lOC_StateRepository;

        public LOC_StateBusiness(ILOC_StateRepository lOC_StateRepository)
        {
            _lOC_StateRepository = lOC_StateRepository;
        }


        #region Insert
        public async Task Insert(int countryId, LOC_State lOC_State)
        {
            try
            {
                await _lOC_StateRepository.Insert(countryId, lOC_State);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion



        #region Update
        public async Task Update(LOC_State lOC_State)
        {
            try
            {
                await _lOC_StateRepository.Update(lOC_State);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion



        #region Delete
        public async Task Delete(int stateId)
        {
            try
            {
                await _lOC_StateRepository.Delete(stateId);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion



        #region Select
        public async Task<List<LOC_State>> SelectAll()
        {
            try
            {
                return await _lOC_StateRepository.SelectAll();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public async Task<List<LOC_State>> SelectByStateID(int stateId)
        {
            try
            {
                return await _lOC_StateRepository.SelectByStateID(stateId);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion
    }
}
