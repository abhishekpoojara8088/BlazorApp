﻿using BANKIFSC_BAL.IBusinessLogic.Admin.LOC;
using BANKIFSC_DAL.IRepository.Admin.LOC;
using BANKIFSC_Shared.Entity.LOC;


namespace BANKIFSC_BAL.BusinessLogic.Admin.LOC
{
    public class LOC_CountryBusiness : ILOC_CountryBusiness
    {
        private readonly ILOC_CountryRepository _lOC_CountryRepository;

        public LOC_CountryBusiness(ILOC_CountryRepository lOC_CountryRepository)
        {
            _lOC_CountryRepository = lOC_CountryRepository;
        }


        #region Insert
        public async Task Insert(LOC_Country lOC_Country)
        {
            try
            {
                await _lOC_CountryRepository.Insert(lOC_Country);

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion



        #region Update
        public async Task Update(LOC_Country lOC_Country)
        {
            try
            {
               await _lOC_CountryRepository.Update(lOC_Country);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion



        #region Delete
        public async Task Delete(int countryId)
        {
            try
            {
                await _lOC_CountryRepository.Delete(countryId);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion



        #region Select
        public async Task<List<LOC_Country>> SelectAll()
        {
            try
            {
               return await _lOC_CountryRepository.SelectAll();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public async Task<List<LOC_Country>> SelectByCountryID(int countryId)
        {
            try
            {
               return await _lOC_CountryRepository.SelectByCountryID(countryId);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion
    }
}
