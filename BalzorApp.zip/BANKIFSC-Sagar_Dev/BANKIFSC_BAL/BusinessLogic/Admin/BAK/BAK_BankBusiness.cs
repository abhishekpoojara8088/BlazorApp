﻿using BANKIFSC_BAL.IBusinessLogic.Admin.BAK;
using BANKIFSC_DAL.IRepository.Admin.BAK;
using BANKIFSC_DAL.IRepository.Admin.LOC;
using BANKIFSC_Shared.Entity.BAK;
using BANKIFSC_Shared.Entity.LOC;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BANKIFSC_BAL.BusinessLogic.Admin.BAK
{
    public class BAK_BankBusiness : IBAK_BankBusiness
    {
        private readonly IBAK_BankRepository _bAK_BankRepository;

        public BAK_BankBusiness(IBAK_BankRepository bAK_BankRepository)
        {
            _bAK_BankRepository = bAK_BankRepository;
        }


        #region Insert
        public async Task<int> Insert(BAK_Bank bAK_Bank)
        {
            try
            {
               return await _bAK_BankRepository.Insert(bAK_Bank);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        public async Task<string> InsertImage(IFormFile file)
        {
            try
            {
               return await _bAK_BankRepository.InsertImage(file);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion



        #region Update
        public async Task<int> Update(BAK_Bank bAK_Bank)
        {
            try
            {
               return await _bAK_BankRepository.Update(bAK_Bank);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion



        #region Delete
        public async Task Delete(int bankId)
        {
            try
            {
                await _bAK_BankRepository.Delete(bankId);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        public async Task DeleteImage(string deleteImagePath)
        {
            try
            {
                await _bAK_BankRepository.DeleteImage(deleteImagePath);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion



        #region Select
        public async Task<List<BAK_Bank>> SelectAll()
        {
            try
            {
                return await _bAK_BankRepository.SelectAll();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public async Task<List<BAK_Bank>> SelectByBankID(int bankId)
        {
            try
            {
                return await _bAK_BankRepository.SelectByBankID(bankId);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion
    }
}
