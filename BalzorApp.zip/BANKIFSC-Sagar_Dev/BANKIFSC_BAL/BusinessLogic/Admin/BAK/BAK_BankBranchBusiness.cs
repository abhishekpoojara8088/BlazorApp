﻿using BANKIFSC_BAL.IBusinessLogic.Admin.BAK;
using BANKIFSC_DAL.IRepository.Admin.BAK;
using BANKIFSC_DAL.Repository.Admin.BAK;
using BANKIFSC_Shared.Entity.BAK;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BANKIFSC_BAL.BusinessLogic.Admin.BAK
{
    public class BAK_BankBranchBusiness : IBAK_BankBranchBusiness
    {
        private readonly IBAK_BankBranchRepository _bAK_BankBranchRepository;

        public BAK_BankBranchBusiness(IBAK_BankBranchRepository bAK_BankBranchRepository)
        {
            _bAK_BankBranchRepository = bAK_BankBranchRepository;
        }

        #region Insert
        public async Task<int> Insert(BAK_BankBranch bAK_BankBranch)
        {
            try
            {
                return await _bAK_BankBranchRepository.Insert(bAK_BankBranch);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion



        #region Update
        public async Task<int> Update(BAK_BankBranch bAK_BankBranch)
        {
            try
            {
                return await _bAK_BankBranchRepository.Update(bAK_BankBranch);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion



        #region Delete
        public async Task Delete(int branchId)
        {
            try
            {
                await _bAK_BankBranchRepository.Delete(branchId);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion



        #region Select
        public async Task<List<BAK_BankBranch>> SelectAll()
        {
            try
            {
                return await _bAK_BankBranchRepository.SelectAll();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public async Task<List<BAK_BankBranch>> SelectByBranchID(int branchId)
        {
            try
            {
                return await _bAK_BankBranchRepository.SelectByBranchID(branchId);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion
    }
}
