﻿using BANKIFSC_Shared.Entity.BAK;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BANKIFSC_BAL.IBusinessLogic.Admin.BAK
{
    public interface IBAK_BankBranchBusiness
    {
        #region Insert
        Task<int> Insert(BAK_BankBranch bAK_BankBranch);
        #endregion


        #region Update
        Task<int> Update(BAK_BankBranch bAK_BankBranch);
        #endregion


        #region Delete
        Task Delete(int branchId);
        #endregion


        #region Select
        Task<List<BAK_BankBranch>> SelectAll();
        Task<List<BAK_BankBranch>> SelectByBranchID(int branchId);
        #endregion
    }
}
