﻿using BANKIFSC_Shared.Entity.BAK;
using BANKIFSC_Shared.Entity.LOC;
using Microsoft.AspNetCore.Http;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BANKIFSC_BAL.IBusinessLogic.Admin.BAK
{
    public interface IBAK_BankBusiness
    {
        #region Insert
        Task<int> Insert(BAK_Bank bAK_Bank);
        Task<string> InsertImage(IFormFile file);
        #endregion


        #region Update
        Task<int> Update(BAK_Bank bAK_Bank);
        #endregion


        #region Delete
        Task Delete(int bankId);
        Task DeleteImage(string deleteImagePath);
        #endregion


        #region Select
        Task<List<BAK_Bank>> SelectAll();
        Task<List<BAK_Bank>> SelectByBankID(int bankId);
        #endregion
    }
}
