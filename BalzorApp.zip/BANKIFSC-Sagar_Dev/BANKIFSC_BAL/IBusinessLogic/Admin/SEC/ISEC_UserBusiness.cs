﻿using BANKIFSC_Shared.Entity.LOC;
using BANKIFSC_Shared.Entity.SEC;

namespace BANKIFSC_BAL.IBusinessLogic.Admin.SEC
{
    public interface ISEC_UserBusiness
    {
        #region Select
        Task<List<SEC_User>> SelectAll();
        #endregion

    }
}
