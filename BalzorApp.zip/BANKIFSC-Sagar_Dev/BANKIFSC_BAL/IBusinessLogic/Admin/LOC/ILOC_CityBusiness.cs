﻿using BANKIFSC_Shared.Entity.LOC;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BANKIFSC_BAL.IBusinessLogic.Admin.LOC
{
    public interface ILOC_CityBusiness
    {
        #region Insert
        Task Insert(int stateId, LOC_City lOC_City);
        #endregion


        #region Update
        Task Update(LOC_City lOC_City);
        #endregion


        #region Delete
        Task Delete(int cityId);
        #endregion


        #region Select
        Task<List<LOC_City>> SelectAll();
        Task<List<LOC_City>> SelectByCityID(int cityId);
        #endregion
    }
}
