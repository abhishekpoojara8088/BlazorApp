﻿using BANKIFSC_Shared.Entity.LOC;


namespace BANKIFSC_BAL.IBusinessLogic.Admin.LOC
{
    public interface ILOC_CountryBusiness
    {
        #region Insert
        Task Insert(LOC_Country lOC_Country);
        #endregion


        #region Update
        Task Update(LOC_Country lOC_Country);
        #endregion


        #region Delete
        Task Delete(int countryId);
        #endregion


        #region Select
        Task<List<LOC_Country>> SelectAll();
        Task<List<LOC_Country>> SelectByCountryID(int countryId);
        #endregion
    }
}
