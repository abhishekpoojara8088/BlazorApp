﻿using BANKIFSC_Shared.Entity.LOC;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BANKIFSC_BAL.IBusinessLogic.Admin.LOC
{
    public interface ILOC_StateBusiness
    {
        #region Insert
        Task Insert(int countryId, LOC_State lOC_State);
        #endregion


        #region Update
        Task Update(LOC_State lOC_State);
        #endregion


        #region Delete
        Task Delete(int stateId);
        #endregion


        #region Select
        Task<List<LOC_State>> SelectAll();
        Task<List<LOC_State>> SelectByStateID(int stateId);
        #endregion
    }
}
