﻿using Dapper;
using Microsoft.Data.SqlClient;
using System.Data;

namespace BANKIFSC
{
    public class BANKIFSC
    {
        public class ConnectionManager
        {
            private static readonly Dictionary<string, string> connections = new Dictionary<string, string>();
            public static void AddConnection(string name, string connectionString)
            {
                connections.Add(name, connectionString);
            }
            public static IDbConnection OpenConnection(string connection)
            {
                SqlConnection sqlConnection = new SqlConnection(connections[connection]);
                sqlConnection.Execute("set transaction isolation level read uncommitted;");
                return sqlConnection;
            }
        }
    }
}
