﻿using BANKIFSC_Shared.Entity.BAK;
using BANKIFSC_Shared.Entity.LOC;
using BANKIFSC_Shared.Entity.SEC;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BANKIFSC_DAL.Data
{

    public class BANKIFSCDbContext : DbContext
    {
        protected readonly IConfiguration Configuration;

        public BANKIFSCDbContext(IConfiguration configuration)
        {
            Configuration = configuration;
        }
        
        public DbSet<LOC_Country> LOC_Country { get; set; }
        
        public DbSet<LOC_State> LOC_State { get; set; }
        public DbSet<LOC_City> LOC_City { get; set; }
        public DbSet<SEC_User> SEC_User { get; set; }
        public DbSet<BAK_Bank> BAK_Banks { get; set; }
        public DbSet<BAK_BankBranch> BAK_BankBranches { get; set; }

       
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Server=tcp:DESKTOP-A8K3B6E,49172;Database=BANKIFSC;User ID=testdemo;password=test@123;Integrated Security=False;Trusted_Connection=False;Encrypt=False;");
            base.OnConfiguring(optionsBuilder);
        }
    }

}
