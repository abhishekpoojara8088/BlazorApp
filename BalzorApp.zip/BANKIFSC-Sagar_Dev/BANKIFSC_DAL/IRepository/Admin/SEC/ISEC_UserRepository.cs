﻿
using BANKIFSC_Shared.Entity.SEC;

namespace BANKIFSC_DAL.IRepository.Admin.SEC
{
    public interface ISEC_UserRepository
    {
        #region Select
        Task<List<SEC_User>> SelectAll();
        #endregion
    }
}
