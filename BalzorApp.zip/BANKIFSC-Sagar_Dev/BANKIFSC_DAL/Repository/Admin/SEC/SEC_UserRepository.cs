﻿using BANKIFSC_DAL.Data;
using BANKIFSC_Shared.Entity.LOC;
using Microsoft.EntityFrameworkCore;
using Microsoft.Data.SqlClient;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;
using Microsoft.IdentityModel.Protocols;
using System.Data;
using MaxMind.GeoIP2.Model;
using Microsoft.IdentityModel.Tokens;
using BANKIFSC_DAL.IRepository.Admin.SEC;
using BANKIFSC_Shared.Entity.SEC;
using BANKIFSC_Shared.Authentication;

namespace BANKIFSC_DAL.Repository.Admin.SEC
{
    public class SEC_UserRepository : ISEC_UserRepository
    {


        SqlConnection con = new SqlConnection(ConnectionString.SqlConnectionString);

        private readonly BANKIFSCDbContext _context;

        public SEC_UserRepository(BANKIFSCDbContext context)
        {
            _context = context;

        }

        #region Select
        public async Task<List<SEC_User>> SelectAll()
        {
            try
            {
                var response = await _context.SEC_User
                              .FromSqlRaw("PR_SEC_User_SelectAll")
                              .ToListAsync();
                return response;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion
    }

}
