﻿using BANKIFSC_DAL.Data;
using BANKIFSC_DAL.IRepository.Admin.LOC;
using BANKIFSC_Shared.Authentication;
using BANKIFSC_Shared.Entity.LOC;
using MaxMind.GeoIP2.Model;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BANKIFSC_DAL.Repository.Admin.LOC
{
    public class LOC_StateRepository : ILOC_StateRepository
    {
        SqlConnection con = new SqlConnection(ConnectionString.SqlConnectionString);

        private readonly BANKIFSCDbContext _context;

        public LOC_StateRepository(BANKIFSCDbContext context)
        {
            _context = context;

        }

        #region Insert
        public async Task Insert(int countryId, LOC_State lOC_State)
        {
            try
            {
                int StateID = 0;

                con.Open();
                SqlCommand command = new SqlCommand("PR_LOC_State_Insert", con);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@StateName", lOC_State.StateName);
                command.Parameters.AddWithValue("@CountryID", countryId);
                command.Parameters.AddWithValue("@UserID", 1);
                if (lOC_State.Remarks == null)
                {
                    lOC_State.Remarks = "";
                }
                command.Parameters.AddWithValue("@Remarks", lOC_State.Remarks == "" ? DBNull.Value : lOC_State.Remarks);
                command.Parameters.Add("@StateID", SqlDbType.Int).Direction = ParameterDirection.Output;
                command.ExecuteNonQuery();
                StateID = Convert.ToInt32(command.Parameters["@StateID"].Value);
                con.Close();

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion


        #region Update
        public async Task Update(LOC_State lOC_State)
        {
            try
            {
                int StateID = lOC_State.StateID;

                con.Open();
                SqlCommand command = new SqlCommand("PR_LOC_State_Update", con);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@StateName", lOC_State.StateName);
                command.Parameters.AddWithValue("@UserID", 2);

                if (lOC_State.Remarks == null)
                {
                    lOC_State.Remarks = "";
                }
                command.Parameters.AddWithValue("@Remarks", lOC_State.Remarks == "" ? DBNull.Value : lOC_State.Remarks);
                command.Parameters.AddWithValue("@StateID", lOC_State.StateID);
                command.ExecuteNonQuery();
                StateID = Convert.ToInt32(command.Parameters["@StateID"].Value);
                con.Close();

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion


        #region Delete
        public async Task Delete(int stateId)
        {
            try 
            {
                await Task.Run(() => _context.Database.ExecuteSqlInterpolatedAsync($"PR_LOC_State_Delete {stateId}"));
            } 
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion


        #region Select
        public async Task<List<LOC_State>> SelectAll()
        {
            try
            {
                var response = await _context.LOC_State
                               .FromSqlRaw("PR_LOC_State_SelectAll")
                               .ToListAsync();
                return response;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public async Task<List<LOC_State>> SelectByStateID(int stateId)
        {
            try
            {
                var parameter = new SqlParameter("@StateID", stateId);

                var stateDetails = await Task.Run(() => _context.LOC_State
                                .FromSqlRaw(@"exec PR_LOC_State_SelectByStateID @StateID", parameter).ToListAsync());

                return stateDetails;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion
    }
}
