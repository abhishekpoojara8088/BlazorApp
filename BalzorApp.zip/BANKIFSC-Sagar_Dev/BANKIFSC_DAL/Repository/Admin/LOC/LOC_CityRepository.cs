﻿using BANKIFSC_DAL.Data;
using BANKIFSC_DAL.IRepository.Admin.LOC;
using BANKIFSC_Shared.Authentication;
using BANKIFSC_Shared.Entity.LOC;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BANKIFSC_DAL.Repository.Admin.LOC
{
    public class LOC_CityRepository : ILOC_CityRepository
    {
        SqlConnection con = new SqlConnection(ConnectionString.SqlConnectionString);

        private readonly BANKIFSCDbContext _context;

        public LOC_CityRepository(BANKIFSCDbContext context)
        {
            _context = context;

        }

        #region Insert
        public async Task Insert(int stateId, LOC_City lOC_City)
        {
            try
            {
                int CityID = 0;

                con.Open();
                SqlCommand command = new SqlCommand("PR_LOC_City_Insert", con);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@CityName", lOC_City.CityName);
                command.Parameters.AddWithValue("@StateID", stateId);
                command.Parameters.AddWithValue("@UserID", 1);
                if (lOC_City.Remarks == null)
                {
                    lOC_City.Remarks = "";
                }
                command.Parameters.AddWithValue("@Remarks", lOC_City.Remarks == "" ? DBNull.Value : lOC_City.Remarks);
                command.Parameters.Add("@CityID", SqlDbType.Int).Direction = ParameterDirection.Output;
                command.ExecuteNonQuery();
                CityID = Convert.ToInt32(command.Parameters["@CityID"].Value);
                con.Close();

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion


        #region Update
        public async Task Update(LOC_City lOC_City)
        {
            try
            {
                int CityID = lOC_City.CityID;

                con.Open();
                SqlCommand command = new SqlCommand("PR_LOC_City_Update", con);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@CityName", lOC_City.CityName);
                command.Parameters.AddWithValue("@UserID", 2);

                if (lOC_City.Remarks == null)
                {
                    lOC_City.Remarks = "";
                }
                command.Parameters.AddWithValue("@Remarks", lOC_City.Remarks == "" ? DBNull.Value : lOC_City.Remarks);
                command.Parameters.AddWithValue("@CityID", lOC_City.CityID);
                command.ExecuteNonQuery();
                CityID = Convert.ToInt32(command.Parameters["@CityID"].Value);
                con.Close();

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion


        #region Delete
        public async Task Delete(int cityId)
        {
            try
            {
                await Task.Run(() => _context.Database.ExecuteSqlInterpolatedAsync($"PR_LOC_City_Delete {cityId}"));
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion


        #region Select
        public async Task<List<LOC_City>> SelectAll()
        {
            try
            {
                var response = await _context.LOC_City
                               .FromSqlRaw("PR_LOC_City_SelectAll")
                               .ToListAsync();
                return response;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public async Task<List<LOC_City>> SelectByCityID(int cityId)
        {
            try
            {
                var parameter = new SqlParameter("@CityID", cityId);

                var cityDetails = await Task.Run(() => _context.LOC_City
                                .FromSqlRaw(@"exec PR_LOC_City_SelectByCityID @CityID", parameter).ToListAsync());

                return cityDetails;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion
    }
}
