﻿using BANKIFSC_DAL.Data;
using BANKIFSC_Shared.Entity.LOC;
using Microsoft.EntityFrameworkCore;
using Microsoft.Data.SqlClient;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;
using Microsoft.IdentityModel.Protocols;
using System.Data;
using MaxMind.GeoIP2.Model;
using Microsoft.IdentityModel.Tokens;
using BANKIFSC_DAL.IRepository.Admin.LOC;
using BANKIFSC_Shared.Authentication;

namespace BANKIFSC_DAL.Repository.Admin.LOC
{
    public class LOC_CountryRepository : ILOC_CountryRepository
    {
        
        SqlConnection con = new SqlConnection(ConnectionString.SqlConnectionString);

        private readonly BANKIFSCDbContext _context;

        public LOC_CountryRepository(BANKIFSCDbContext context)
        {
            _context = context;

        }

        #region Insert
        public async Task Insert(LOC_Country lOC_Country)
        {
            try
            {
                int CountryID = 0;

                con.Open();
                SqlCommand command = new SqlCommand("PR_LOC_Country_Insert", con);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@CountryName", lOC_Country.CountryName);
                command.Parameters.AddWithValue("@UserID", 1);
                if (lOC_Country.Remarks == null)
                {
                    lOC_Country.Remarks = "";
                }
                command.Parameters.AddWithValue("@Remarks", lOC_Country.Remarks == "" ? DBNull.Value : lOC_Country.Remarks);
                command.Parameters.Add("@CountryID", SqlDbType.Int).Direction = ParameterDirection.Output;
                command.ExecuteNonQuery();
                CountryID = Convert.ToInt32(command.Parameters["@CountryID"].Value);
                con.Close();

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion



        #region Update
        public async Task Update(LOC_Country lOC_Country)
        {
            try
            {
                int CountryID = lOC_Country.CountryID;

                con.Open();
                SqlCommand command = new SqlCommand("PR_LOC_Country_Update", con);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@CountryName", lOC_Country.CountryName);
                command.Parameters.AddWithValue("@UserID", 2);
                if (lOC_Country.Remarks == null)
                {
                    lOC_Country.Remarks = "";
                }
                command.Parameters.AddWithValue("@Remarks", lOC_Country.Remarks == "" ? DBNull.Value : lOC_Country.Remarks);
                command.Parameters.AddWithValue("@CountryID", lOC_Country.CountryID);
                command.ExecuteNonQuery();
                CountryID = Convert.ToInt32(command.Parameters["@CountryID"].Value);
                con.Close();

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion



        #region Delete
        public async Task Delete(int countryId)
        {
            try
            {
                await Task.Run(() => _context.Database.ExecuteSqlInterpolatedAsync($"PR_LOC_Country_Delete {countryId}"));
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion



        #region Select
        public async Task<List<LOC_Country>> SelectAll()
        {
            try
            {
                var response = await _context.LOC_Country
                              .FromSqlRaw("PR_LOC_Country_SelectAll")
                              .ToListAsync();
                return response;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public async Task<List<LOC_Country>> SelectByCountryID(int countryId)
        {
            try
            {
                var parameter = new SqlParameter("@CountryID", countryId);

                var countryDetails = await Task.Run(() => _context.LOC_Country
                                .FromSqlRaw(@"exec PR_LOC_Country_SelectByCountryID @CountryID", parameter)
                                .ToListAsync());

                return countryDetails;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion
    }

}
