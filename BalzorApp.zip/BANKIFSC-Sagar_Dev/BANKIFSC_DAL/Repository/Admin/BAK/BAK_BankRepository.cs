﻿using BANKIFSC_DAL.Data;
using BANKIFSC_DAL.IRepository.Admin.BAK;
using BANKIFSC_Shared.Authentication;
using BANKIFSC_Shared.Entity.BAK;
using BANKIFSC_Shared.Entity.LOC;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BANKIFSC_DAL.Repository.Admin.BAK
{
    public class BAK_BankRepository : IBAK_BankRepository
    {

        SqlConnection con = new SqlConnection(ConnectionString.SqlConnectionString);

        private readonly BANKIFSCDbContext _context;
        
        public BAK_BankRepository(BANKIFSCDbContext context)
        {
            _context = context;

        }

        #region Insert
        public async Task<int> Insert(BAK_Bank bAK_Bank)
        {
            try
            {
                int BankID = 0;
                con.Open();
                SqlCommand command = new SqlCommand("PR_BAK_Bank_Insert", con);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@BankName", bAK_Bank.BankName);
                command.Parameters.AddWithValue("@Address", bAK_Bank.Address);
                command.Parameters.AddWithValue("@ContactNo", bAK_Bank.ContactNo);
                command.Parameters.AddWithValue("@FAX", bAK_Bank.FAX);
                command.Parameters.AddWithValue("@Website", bAK_Bank.Website);
                command.Parameters.AddWithValue("@Email", bAK_Bank.Email);
                if (bAK_Bank.ImageURL != null)
                {
                    string basePath = AppDomain.CurrentDomain.BaseDirectory;
                    string filePath = Path.Combine(basePath.Substring(0, basePath.IndexOf("BANKIFSC_API")) + "BANKIFSC_Web", "wwwroot", "images", bAK_Bank.ImageURL);
                    bAK_Bank.ImageURL = filePath.Substring(filePath.IndexOf("wwwroot"));
                }
                if (bAK_Bank.Remarks == null)
                {
                    bAK_Bank.Remarks = "";
                }
                command.Parameters.AddWithValue("@ImageURL", bAK_Bank.ImageURL == null ? DBNull.Value : bAK_Bank.ImageURL);
                command.Parameters.AddWithValue("@UserID", 1);
                command.Parameters.AddWithValue("@Remarks", bAK_Bank.Remarks == "" ? DBNull.Value : bAK_Bank.Remarks);
                command.Parameters.Add("@BankID", SqlDbType.Int).Direction = ParameterDirection.Output;
                command.ExecuteNonQuery();
                BankID = Convert.ToInt32(command.Parameters["@BankID"].Value);
                con.Close();
                return BankID;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public async Task<string> InsertImage(IFormFile file)
        {
            try
            {
                if (file == null || file.Length == 0)
                    return "No file found in request";

                
                    string basePath = AppDomain.CurrentDomain.BaseDirectory;
                    string filePath = Path.Combine(basePath.Substring(0, basePath.IndexOf("BANKIFSC_API")) + "BANKIFSC_Web", "wwwroot", "images", file.FileName);
                    using (var stream = new FileStream(filePath, FileMode.Create))
                    {
                        await file.CopyToAsync(stream);
                    }
                    //File.Delete(filePath);
                    return "Image Uploaded Successfully";
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion



        #region Update
        public async Task<int> Update(BAK_Bank bAK_Bank)
        {
            try
            {
                int BankID = bAK_Bank.BankID;

                con.Open();
                SqlCommand command = new SqlCommand("PR_BAK_Bank_Update", con);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@BankName", bAK_Bank.BankName);
                command.Parameters.AddWithValue("@Address", bAK_Bank.Address);
                command.Parameters.AddWithValue("@ContactNo", bAK_Bank.ContactNo);
                command.Parameters.AddWithValue("@FAX", bAK_Bank.FAX);
                command.Parameters.AddWithValue("@Website", bAK_Bank.Website);
                command.Parameters.AddWithValue("@Email", bAK_Bank.Email);
                if (bAK_Bank.Remarks == null )
                {
                    bAK_Bank.Remarks = "";
                }
                if (bAK_Bank.ImageURL != null)
                {
                    string basePath = AppDomain.CurrentDomain.BaseDirectory;
                    string filePath = Path.Combine(basePath.Substring(0, basePath.IndexOf("BANKIFSC_API")) + "BANKIFSC_Web", "wwwroot", "images", bAK_Bank.ImageURL);
                    bAK_Bank.ImageURL = filePath.Substring(filePath.IndexOf("wwwroot"));
                }
                command.Parameters.AddWithValue("@ImageURL", bAK_Bank.ImageURL == null ? DBNull.Value : bAK_Bank.ImageURL);
                command.Parameters.AddWithValue("@UserID", 2);
                command.Parameters.AddWithValue("@Remarks", bAK_Bank.Remarks == "" ? DBNull.Value : bAK_Bank.Remarks);
                command.Parameters.AddWithValue("@BankID", bAK_Bank.BankID);
                command.ExecuteNonQuery();
                BankID = Convert.ToInt32(command.Parameters["@BankID"].Value);
                con.Close();
                return BankID;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion



        #region Delete
        public async Task Delete(int bankId)
        {
            try
            {
                await Task.Run(() => _context.Database.ExecuteSqlInterpolatedAsync($"PR_BAK_Bank_Delete {bankId}"));
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        public async Task DeleteImage(string deleteImagePath)
        {
            try
            {
                string basePath = AppDomain.CurrentDomain.BaseDirectory;
                string filePath = Path.Combine(basePath.Substring(0, basePath.IndexOf("BANKIFSC_API")) + "BANKIFSC_Web", deleteImagePath);
               // filePath.Substring(filePath.IndexOf("wwwroot"));
                
                File.Delete(filePath);
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }
        #endregion



        #region Select
        public async Task<List<BAK_Bank>> SelectAll()
        {
            try
            {
                var response = await _context.BAK_Banks
                              .FromSqlRaw("PR_BAK_Bank_SelectAll")
                              .ToListAsync();
                return response;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public async Task<List<BAK_Bank>> SelectByBankID(int bankId)
        {
            try
            {
                var parameter = new SqlParameter("@BankID", bankId);

                var bankDetails = await Task.Run(() => _context.BAK_Banks
                                .FromSqlRaw(@"exec PR_BAK_Bank_SelectByBankID @BankID", parameter)
                                .ToListAsync());

                return bankDetails;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion
    }
}
