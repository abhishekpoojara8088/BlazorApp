﻿using BANKIFSC_DAL.Data;
using BANKIFSC_DAL.IRepository.Admin.BAK;
using BANKIFSC_Shared.Authentication;
using BANKIFSC_Shared.Entity.BAK;
using Microsoft.AspNetCore.Http;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BANKIFSC_DAL.Repository.Admin.BAK
{
    public class BAK_BankBranchRepository : IBAK_BankBranchRepository
    {
        SqlConnection con = new SqlConnection(ConnectionString.SqlConnectionString);

        private readonly BANKIFSCDbContext _context;

        public BAK_BankBranchRepository(BANKIFSCDbContext context)
        {
            _context = context;

        }

        #region Insert
        public async Task<int> Insert(BAK_BankBranch bAK_BankBranch)
        {
            try
            {
                int BranchID = 0;
                con.Open();
                SqlCommand command = new SqlCommand("PR_BAK_BankBranch_Insert", con);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@BankID", bAK_BankBranch.BankID);
                command.Parameters.AddWithValue("@CityID", bAK_BankBranch.CityID);
                command.Parameters.AddWithValue("@BranchName", bAK_BankBranch.BranchName);
                command.Parameters.AddWithValue("@IFSC", bAK_BankBranch.IFSC);
                command.Parameters.AddWithValue("@Address", bAK_BankBranch.Address);
                command.Parameters.AddWithValue("@ContactNo", bAK_BankBranch.ContactNo);
                command.Parameters.AddWithValue("@PIN", bAK_BankBranch.PIN);
                command.Parameters.AddWithValue("@UserID", 1);
                if (bAK_BankBranch.Remarks == null)
                {
                    bAK_BankBranch.Remarks = "";
                }
                command.Parameters.AddWithValue("@Remarks", bAK_BankBranch.Remarks == "" ? DBNull.Value : bAK_BankBranch.Remarks);
                command.Parameters.Add("@BranchID", SqlDbType.Int).Direction = ParameterDirection.Output;
                command.ExecuteNonQuery();
                BranchID = Convert.ToInt32(command.Parameters["@BranchID"].Value);
                con.Close();
                return BranchID;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion



        #region Update
        public async Task<int> Update(BAK_BankBranch bAK_BankBranch)
        {
            try
            {
                int BranchID = bAK_BankBranch.BranchID;

                con.Open();
                SqlCommand command = new SqlCommand("PR_BAK_BankBranch_Update", con);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@BranchName", bAK_BankBranch.BranchName);
                
                command.Parameters.AddWithValue("@Address", bAK_BankBranch.Address);
                command.Parameters.AddWithValue("@ContactNo", bAK_BankBranch.ContactNo);
                command.Parameters.AddWithValue("@PIN", bAK_BankBranch.PIN);
                command.Parameters.AddWithValue("@IFSC", bAK_BankBranch.IFSC);
                
                if (bAK_BankBranch.Remarks == null)
                {
                    bAK_BankBranch.Remarks = "";
                }
                command.Parameters.AddWithValue("@UserID", 2);
                command.Parameters.AddWithValue("@Remarks", bAK_BankBranch.Remarks == "" ? DBNull.Value : bAK_BankBranch.Remarks);
                command.Parameters.AddWithValue("@BranchID", bAK_BankBranch.BranchID);
                command.ExecuteNonQuery();
                BranchID = Convert.ToInt32(command.Parameters["@BranchID"].Value);
                con.Close();
                return BranchID;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion



        #region Delete
        public async Task Delete(int branchId)
        {
            try
            {
                await Task.Run(() => _context.Database.ExecuteSqlInterpolatedAsync($"PR_BAK_BankBranch_Delete {branchId}"));
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion



        #region Select
        public async Task<List<BAK_BankBranch>> SelectAll()
        {
            try
            {
                var response = await _context.BAK_BankBranches
                              .FromSqlRaw("PR_BAK_BankBranch_SelectAll")
                              .ToListAsync();
                return response;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public async Task<List<BAK_BankBranch>> SelectByBranchID(int branchId)
        {
            try
            {
                var parameter = new SqlParameter("@BranchID", branchId);

                var bankBranchDetails = await Task.Run(() => _context.BAK_BankBranches
                                .FromSqlRaw(@"exec PR_BAK_BankBranch_SelectByBranchID @BranchID", parameter)
                                .ToListAsync());

                return bankBranchDetails;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion

    }
}
