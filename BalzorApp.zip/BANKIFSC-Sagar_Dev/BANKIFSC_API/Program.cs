using BANKIFSC_DAL.Data;
using MudBlazor;
using Microsoft.EntityFrameworkCore;
using MudBlazor.Services;
using BANKIFSC_Web;
using Microsoft.AspNetCore.Components.WebAssembly.Hosting;
using BANKIFSC_BAL.BusinessLogic.Admin.LOC;
using BANKIFSC_BAL.IBusinessLogic.Admin.LOC;
using BANKIFSC_DAL.IRepository.Admin.LOC;
using BANKIFSC_DAL.Repository.Admin.LOC;
using BANKIFSC_BAL.BusinessLogic.Admin.SEC;
using BANKIFSC_BAL.IBusinessLogic.Admin.SEC;
using BANKIFSC_DAL.IRepository.Admin.SEC;
using BANKIFSC_DAL.Repository.Admin.SEC;
using BANKIFSC_BAL.IBusinessLogic.Admin.BAK;
using BANKIFSC_BAL.BusinessLogic.Admin.BAK;
using BANKIFSC_DAL.IRepository.Admin.BAK;
using BANKIFSC_DAL.Repository.Admin.BAK;
using Microsoft.AspNetCore.Components.Server.ProtectedBrowserStorage;
using Microsoft.AspNetCore.Components.Authorization;
using BANKIFSC_Shared.Entity.SEC;
using BANKIFSC_API.Authentication;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using System.Text;
using Microsoft.IdentityModel.Tokens;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllers();

builder.Services.AddDbContext<BANKIFSCDbContext>(options => options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

builder.Services.AddScoped<ILOC_CountryBusiness, LOC_CountryBusiness>();
builder.Services.AddScoped<ILOC_CountryRepository, LOC_CountryRepository>();

builder.Services.AddScoped<ILOC_StateBusiness, LOC_StateBusiness>();
builder.Services.AddScoped<ILOC_StateRepository, LOC_StateRepository>();

builder.Services.AddScoped<ILOC_CityBusiness, LOC_CityBusiness>();
builder.Services.AddScoped<ILOC_CityRepository, LOC_CityRepository>();

builder.Services.AddScoped<IBAK_BankBusiness, BAK_BankBusiness>();
builder.Services.AddScoped<IBAK_BankRepository, BAK_BankRepository>();

builder.Services.AddScoped<IBAK_BankBranchBusiness, BAK_BankBranchBusiness>();
builder.Services.AddScoped<IBAK_BankBranchRepository, BAK_BankBranchRepository>();

builder.Services.AddScoped<ISEC_UserBusiness, SEC_UserBusiness>();
builder.Services.AddScoped<ISEC_UserRepository, SEC_UserRepository>();


builder.Services.AddSingleton<HttpClient, HttpClient>();

builder.Services.AddAuthentication(o =>
{
    o.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    o.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
}).AddJwtBearer(o =>
{
    o.RequireHttpsMetadata = false;
    o.SaveToken = true;
    o.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuerSigningKey = true,
        IssuerSigningKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(JwtAuthenticationManager.JWT_SECURITY_KEY)),
        ValidateIssuer = false,
        ValidateAudience = false
    };
});
builder.Services.AddSingleton<UserAccountService>();
builder.Services.AddHttpClient();



// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
//builder.Services.AddMudServices();
builder.Services.AddRazorPages();
builder.Services.AddServerSideBlazor();

var app = builder.Build();

app.UseCors(builder => builder
        .WithOrigins("https://localhost:7133")
        .AllowAnyMethod()
        .AllowAnyHeader());
        

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
    
}


app.UseHttpsRedirection();

app.UseRouting();

app.UseAuthentication();

app.UseAuthorization();

app.MapControllers();


//app.MapBlazorHub();

app.Run();



