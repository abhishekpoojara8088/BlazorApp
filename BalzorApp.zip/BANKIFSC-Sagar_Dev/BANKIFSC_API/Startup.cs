﻿using Microsoft.Extensions.Configuration;
using BANKIFSC_DAL.Data;
using BANKIFSC_Web.Services;
using BANKIFSC_Web;
using MudBlazor.Services;
using BANKIFSC_Web.Services.Admin.LOC.LOC_CountryServices;
using BANKIFSC_Shared.Entity.SEC;

namespace BANKIFSC
{
    public class Startup
    {
        private readonly IWebHostEnvironment _environment;
        public Startup(IConfiguration configuration, IWebHostEnvironment environment)
        {
            Configuration = configuration;
            _environment = environment;
            BANKIFSC.ConnectionManager.AddConnection("Main", Configuration["ConnectionStrings:DefaultConnection"]);
        }
        public IConfiguration Configuration { get; }



        public void ConfigureServices(IServiceCollection services)
        {
            services.AddRazorPages();
            services.AddServerSideBlazor();
            services.AddSingleton<LOC_CountryService>();
            services.AddMudServices();
            services.AddControllersWithViews();
            services.AddMudBlazorDialog();
            services.AddCors();
            
        }
    }
}
