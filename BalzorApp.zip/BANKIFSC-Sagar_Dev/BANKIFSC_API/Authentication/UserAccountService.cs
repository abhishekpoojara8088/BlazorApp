﻿//fetch user name from database .
namespace BANKIFSC_API.Authentication
{
    public class UserAccountService
    {
        private List<UserAccount> _userAccountsList;

        public UserAccountService()
        {
            _userAccountsList = new List<UserAccount>
            {
                new UserAccount{ UserName = "admin", Password = "admin", Role = "Administrator" },
                new UserAccount{ UserName = "user", Password = "user", Role = "User"}
            };
        }

        public UserAccount? GetUserAccountByUserName(string userName)
        {
            return _userAccountsList.FirstOrDefault(x => x.UserName == userName);
        } 
    }
}
