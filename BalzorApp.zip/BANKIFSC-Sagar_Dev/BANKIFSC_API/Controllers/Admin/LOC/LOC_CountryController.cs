﻿using BANKIFSC_Shared.Entity.LOC;
using Microsoft.AspNetCore.Mvc;
using BANKIFSC_BAL.IBusinessLogic.Admin.LOC;
using Microsoft.AspNetCore.Authorization;

namespace BANKIFSC_API.Controllers.Admin.LOC
{
    [Route("api/[controller]")]
    [ApiController]
    public class LOC_CountryController : ControllerBase
    {
        private ILOC_CountryBusiness _lOC_CountryBusiness;

        public LOC_CountryController(ILOC_CountryBusiness lOC_CountryBusiness)
        {
            _lOC_CountryBusiness = lOC_CountryBusiness;

        }

        #region Insert
        [HttpPost]
        public async Task Insert([FromBody] LOC_Country lOC_Country)
        {
            try
            {
                await _lOC_CountryBusiness.Insert(lOC_Country);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        #endregion

        #region Update
        [HttpPut]
        public async Task Update([FromBody] LOC_Country lOC_Country)
        {
            try
            {
                await _lOC_CountryBusiness.Update(lOC_Country);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion

        #region Delete
        [HttpDelete("{countryId}")]
        public async Task Delete(int countryId)
        {
            try
            {
                await _lOC_CountryBusiness.Delete(countryId);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion

        #region Select
        [HttpGet]
        [Route("SelectAll")]
        public async Task<List<LOC_Country>> SelectAll()
        {
            try
            {
               return await _lOC_CountryBusiness.SelectAll();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        [HttpGet("{countryId}")]
        public async Task<List<LOC_Country>> SelectByCountryID(int countryId)
        {
            try
            {
               return await _lOC_CountryBusiness.SelectByCountryID(countryId);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion
    }
}
