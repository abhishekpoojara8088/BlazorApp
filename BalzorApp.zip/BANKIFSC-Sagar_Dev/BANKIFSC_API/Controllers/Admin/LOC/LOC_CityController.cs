﻿using BANKIFSC_BAL.BusinessLogic.Admin.LOC;
using BANKIFSC_BAL.IBusinessLogic.Admin.LOC;
using BANKIFSC_Shared.Entity.LOC;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Data;

namespace BANKIFSC_API.Controllers.Admin.LOC
{
    [Route("api/[controller]")]
    [ApiController]
    public class LOC_CityController : ControllerBase
    {
        private ILOC_CityBusiness _lOC_CityBusiness;

        public LOC_CityController(ILOC_CityBusiness lOC_CityBusiness)
        {
            _lOC_CityBusiness = lOC_CityBusiness;

        }

        #region Insert
        [HttpPost]
        public async Task Insert(int stateId, [FromBody] LOC_City lOC_City)
        {
            try
            {
                await _lOC_CityBusiness.Insert(stateId, lOC_City);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion



        #region Update
        [HttpPut]
        public async Task Update([FromBody] LOC_City lOC_City)
        {
            try
            {
                await _lOC_CityBusiness.Update(lOC_City);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion



        #region Delete
        [HttpDelete("{cityId}")]
        public async Task Delete(int cityId)
        {
            try
            {
                await _lOC_CityBusiness.Delete(cityId);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion



        #region Select
        [HttpGet]
        [Route("SelectAll")]
        public async Task<List<LOC_City>> SelectAll()
        {
            try
            {
                return await _lOC_CityBusiness.SelectAll();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        [HttpGet("{cityId}")]
        public async Task<List<LOC_City>> SelectByCityID(int cityId)
        {
            try
            {
                return await _lOC_CityBusiness.SelectByCityID(cityId);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion

    }
}
