﻿using BANKIFSC_BAL.IBusinessLogic.Admin.LOC;
using BANKIFSC_Shared.Entity.LOC;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Data;

namespace BANKIFSC_API.Controllers.Admin.LOC
{
    [Route("api/[controller]")]
    [ApiController]
    public class LOC_StateController : ControllerBase
    {
        private ILOC_StateBusiness _lOC_StateBusiness;

        public LOC_StateController(ILOC_StateBusiness lOC_StateBusiness)
        {
            _lOC_StateBusiness = lOC_StateBusiness;

        }

        #region Insert
        [HttpPost]
        public async Task Insert(int countryId, [FromBody] LOC_State lOC_State)
        {
            try
            {
                await _lOC_StateBusiness.Insert(countryId, lOC_State);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion



        #region Update
        [HttpPut]
        public async Task Update([FromBody] LOC_State lOC_State)
        {
            try
            {
                await _lOC_StateBusiness.Update(lOC_State);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion



        #region Delete
        [HttpDelete("{stateId}")]
        public async Task Delete(int stateId)
        {
            try
            {
                 await _lOC_StateBusiness.Delete(stateId);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion



        #region Select
        [HttpGet]
        [Route("SelectAll")]
        public async Task<List<LOC_State>> SelectAll()
        {
            try
            {
               return await _lOC_StateBusiness.SelectAll();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        [HttpGet("{stateId}")]
        public async Task<List<LOC_State>> SelectByStateID(int stateId)
        {
            try
            {
                return await _lOC_StateBusiness.SelectByStateID(stateId);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion
    }
}
