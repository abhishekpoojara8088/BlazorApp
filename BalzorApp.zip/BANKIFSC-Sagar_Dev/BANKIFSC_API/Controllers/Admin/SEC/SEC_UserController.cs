﻿
using BANKIFSC_BAL.IBusinessLogic.Admin.SEC;
using BANKIFSC_Shared.Entity.SEC;
using Microsoft.AspNetCore.Mvc;


namespace BANKIFSC_API.Controllers.Admin.SEC
{
    [Route("api/[controller]")]
    [ApiController]
    public class SEC_UserController : ControllerBase
    {
        private ISEC_UserBusiness _sEC_UserBusiness;

        public SEC_UserController(ISEC_UserBusiness sEC_UserBusiness)
        {
            _sEC_UserBusiness = sEC_UserBusiness;

        }

        #region Select
        [HttpGet]
        [Route("SelectAll")]
        public async Task<List<SEC_User>> SelectAll()
        {
            try
            {
               return await _sEC_UserBusiness.SelectAll();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion
    }
}
