﻿using BANKIFSC_BAL.IBusinessLogic.Admin.BAK;
using BANKIFSC_BAL.IBusinessLogic.Admin.LOC;
using BANKIFSC_DAL.IRepository.Admin.BAK;
using BANKIFSC_DAL.Repository.Admin.BAK;
using BANKIFSC_Shared.Entity.BAK;
using BANKIFSC_Shared.Entity.LOC;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Reflection;

namespace BANKIFSC_API.Controllers.Admin.BAK
{
    [Route("api/[controller]")]
    [ApiController]
    public class BAK_BankController : ControllerBase
    {

        private IBAK_BankBusiness _bAK_BankBusiness;
       
        public BAK_BankController(IBAK_BankBusiness bAK_BankBusiness)
        {
            _bAK_BankBusiness = bAK_BankBusiness;
        }

        #region Insert
        [HttpPost]
        public async Task<int> Insert([FromBody] BAK_Bank bAK_Bank)
        {
            try
            {
               return await _bAK_BankBusiness.Insert(bAK_Bank);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        [HttpPost]
        [Route("insertImage")]
        public async Task<string> InsertImage(IFormFile file)
        {
            try
            {
                return await _bAK_BankBusiness.InsertImage(file);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion

        #region Update
        [HttpPut]
        public async Task<int> Update([FromBody] BAK_Bank bAK_Bank)
        {
            try
            {
               return await _bAK_BankBusiness.Update(bAK_Bank);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion

        #region Delete
        [HttpDelete("{bankId}")]
        public async Task Delete(int bankId)
        {
            try
            {
                await _bAK_BankBusiness.Delete(bankId);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        [HttpDelete]
        [Route("deleteImage")]
        public async Task DeleteImage(string deleteImagePath)
        {
            try
            {
                await _bAK_BankBusiness.DeleteImage(deleteImagePath);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion

        #region Select
        [HttpGet]
        [Route("SelectAll")]
        public async Task<List<BAK_Bank>> SelectAll()
        {
            try
            {
                return await _bAK_BankBusiness.SelectAll();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        [HttpGet("{bankId}")]
        public async Task<List<BAK_Bank>> SelectByBankID(int bankId)
        {
            try
            {
                return await _bAK_BankBusiness.SelectByBankID(bankId);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion
    }
}
