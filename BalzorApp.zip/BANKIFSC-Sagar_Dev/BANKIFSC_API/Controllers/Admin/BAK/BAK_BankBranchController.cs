﻿using BANKIFSC_BAL.BusinessLogic.Admin.BAK;
using BANKIFSC_BAL.IBusinessLogic.Admin.BAK;
using BANKIFSC_Shared.Entity.BAK;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BANKIFSC_API.Controllers.Admin.BAK
{
    [Route("api/[controller]")]
    [ApiController]
    public class BAK_BankBranchController : ControllerBase
    {
        private IBAK_BankBranchBusiness _bAK_BankBranchBusiness;
        public BAK_BankBranchController(IBAK_BankBranchBusiness bAK_BankBranchBusiness)
        {
            _bAK_BankBranchBusiness = bAK_BankBranchBusiness;
        }

        #region Insert
        [HttpPost]
        public async Task<int> Insert([FromBody] BAK_BankBranch bAK_BankBranch)
        {
            try
            {
                return await _bAK_BankBranchBusiness.Insert(bAK_BankBranch);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion

        #region Update
        [HttpPut]
        public async Task<int> Update([FromBody] BAK_BankBranch bAK_BankBranch)
        {
            try
            {
                return await _bAK_BankBranchBusiness.Update(bAK_BankBranch);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion

        #region Delete
        [HttpDelete("{branchId}")]
        public async Task Delete(int branchId)
        {
            try
            {
                await _bAK_BankBranchBusiness.Delete(branchId);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion

        #region Select
        [HttpGet]
        [Route("SelectAll")]
        public async Task<List<BAK_BankBranch>> SelectAll()
        {
            try
            {
                return await _bAK_BankBranchBusiness.SelectAll();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        [HttpGet("{bankId}")]
        public async Task<List<BAK_BankBranch>> SelectByBranchID(int branchId)
        {
            try
            {
                return await _bAK_BankBranchBusiness.SelectByBranchID(branchId);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion
    }
}
