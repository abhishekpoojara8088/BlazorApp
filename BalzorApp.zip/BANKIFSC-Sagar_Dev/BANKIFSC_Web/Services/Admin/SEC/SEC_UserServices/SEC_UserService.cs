﻿using BANKIFSC_Shared.Entity.LOC;
using BANKIFSC_Shared.Entity.SEC;
using System.Net.Http.Json;

namespace BANKIFSC_Web.Services.Admin.SEC.SEC_UserServices
{
    public class SEC_UserService : ISEC_UserService
    {
        private readonly HttpClient _httpClient;

        public SEC_UserService(HttpClient httpClient)
        {
            _httpClient = httpClient;

        }

        #region Select
        public async Task<List<SEC_User>> SelectAll()
        {
            try
            {
                var response = await _httpClient.GetFromJsonAsync<List<SEC_User>>("api/SEC_User/SelectAll");
                return response;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion
    }
}
