﻿using BANKIFSC_Shared.Entity.LOC;
using BANKIFSC_Shared.Entity.SEC;

namespace BANKIFSC_Web.Services.Admin.SEC.SEC_UserServices
{
    public interface ISEC_UserService
    {
        #region Select
        Task<List<SEC_User>> SelectAll();
        #endregion
    }
}
