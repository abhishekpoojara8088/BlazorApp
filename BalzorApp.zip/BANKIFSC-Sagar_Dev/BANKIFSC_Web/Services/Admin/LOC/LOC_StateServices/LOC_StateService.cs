﻿using BANKIFSC_Shared.Entity.LOC;
using MaxMind.GeoIP2.Model;
using System.Net.Http.Json;

namespace BANKIFSC_Web.Services.Admin.LOC.LOC_StateServices
{
    public class LOC_StateService : ILOC_StateService
    {
        private readonly HttpClient _httpClient;

        public LOC_StateService(HttpClient httpClient)
        {
            _httpClient = httpClient;

        }

        #region Insert
        public async Task<Task<HttpResponseMessage>> Insert(int countryId, LOC_State lOC_State)
        {
            try
            {
                var response = _httpClient.PostAsJsonAsync("api/LOC_State?countryId=" + countryId, lOC_State);

                return response;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion



        #region Update
        public async Task<HttpResponseMessage> Update(LOC_State lOC_State)
        {
            try
            {
                var response = await _httpClient.PutAsJsonAsync("api/LOC_State/", lOC_State);

                return response;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion



        #region Delete
        public async Task<HttpResponseMessage> Delete(int stateId)
        {
            try
            {
                var response = await _httpClient.DeleteAsync("api/LOC_State/" + stateId);

                return response;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion



        #region Select
        public async Task<List<LOC_State>> SelectAll()
        {
            try
            {
                var response = await _httpClient.GetFromJsonAsync<List<LOC_State>>("api/LOC_State/SelectAll");
                return response;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public async Task<List<LOC_State>> SelectByStateID(int stateId)
        {
            try
            {
                var response = await _httpClient.GetFromJsonAsync<List<LOC_State>>("api/LOC_State/" + stateId);
                return response;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        #endregion
    }
}
