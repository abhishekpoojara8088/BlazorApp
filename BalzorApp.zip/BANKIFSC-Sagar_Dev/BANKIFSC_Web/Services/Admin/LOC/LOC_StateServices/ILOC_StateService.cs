﻿using BANKIFSC_Shared.Entity.LOC;

namespace BANKIFSC_Web.Services.Admin.LOC.LOC_StateServices
{
    public interface ILOC_StateService
    {
        #region Insert
        Task<Task<HttpResponseMessage>> Insert(int countryId, LOC_State lOC_State);
        #endregion


        #region Update
        Task<HttpResponseMessage> Update(LOC_State lOC_State);
        #endregion


        #region Delete
        Task<HttpResponseMessage> Delete(int stateId);
        #endregion


        #region Select
        Task<List<LOC_State>> SelectAll();
        Task<List<LOC_State>> SelectByStateID(int stateId);
        #endregion
    }
}
