﻿using BANKIFSC_Shared.Entity.LOC;
using Microsoft.EntityFrameworkCore;
using System.Net.Http.Json;
using static System.Net.WebRequestMethods;

namespace BANKIFSC_Web.Services.Admin.LOC.LOC_CountryServices
{

    public class LOC_CountryService : ILOC_CountryService
    {
        private readonly HttpClient _httpClient;

        public LOC_CountryService(HttpClient httpClient)
        {
            _httpClient = httpClient;

        }

        #region Insert
        public async Task<Task<HttpResponseMessage>> Insert(LOC_Country lOC_Country)
        {
            try
            {
                var response = _httpClient.PostAsJsonAsync("api/LOC_Country", lOC_Country);

                return response;
            }
            catch(Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion


        #region Update
        public async Task<HttpResponseMessage> Update(LOC_Country lOC_Country)
        {
            try
            {
                var response = await _httpClient.PutAsJsonAsync("api/LOC_Country/", lOC_Country);

                return response;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion


        #region Delete
        public async Task<HttpResponseMessage> Delete(int countryId)
        {
            try
            {
                var response = await _httpClient.DeleteAsync("api/LOC_Country/" + countryId);

                return response;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion


        #region Select
        public async Task<List<LOC_Country>> SelectAll()
        {
            try
            {
                var response = await _httpClient.GetFromJsonAsync<List<LOC_Country>>("api/LOC_Country/SelectAll");
                return response;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public async Task<LOC_Country> SelectByCountryID(int countryId)
        {
            try
            {
                var response = await _httpClient.GetFromJsonAsync<LOC_Country>("api/LOC_Country/" + countryId);
                return response;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion
    }

}
