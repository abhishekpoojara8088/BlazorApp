﻿using BANKIFSC_Shared.Entity.LOC;

namespace BANKIFSC_Web.Services.Admin.LOC.LOC_CountryServices
{
    public interface ILOC_CountryService
    {
        #region Insert
        Task<Task<HttpResponseMessage>> Insert(LOC_Country lOC_Country);
        #endregion


        #region Update
        Task<HttpResponseMessage> Update(LOC_Country lOC_Country);
        #endregion


        #region Delete
        Task<HttpResponseMessage> Delete(int countryId);
        #endregion


        #region Select
        Task<List<LOC_Country>> SelectAll();
        Task<LOC_Country> SelectByCountryID(int countryId);
        #endregion
    }
}
