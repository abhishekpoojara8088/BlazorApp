﻿using BANKIFSC_Shared.Entity.LOC;
using System.Net.Http.Json;

namespace BANKIFSC_Web.Services.Admin.LOC.LOC_CityServices
{
    public class LOC_CityService : ILOC_CityService
    {
        private readonly HttpClient _httpClient;

        public LOC_CityService(HttpClient httpClient)
        {
            _httpClient = httpClient;

        }

        #region Insert
        public async Task<Task<HttpResponseMessage>> Insert(int stateId, LOC_City lOC_City)
        {
            try
            {
                var response = _httpClient.PostAsJsonAsync("api/LOC_City?stateId=" + stateId, lOC_City);

                return response;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion



        #region Update
        public async Task<HttpResponseMessage> Update(LOC_City lOC_City)
        {
            try
            {
                var response = await _httpClient.PutAsJsonAsync("api/LOC_City/", lOC_City);

                return response;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion



        #region Delete
        public async Task<HttpResponseMessage> Delete(int cityId)
        {
            try
            {
                var response = await _httpClient.DeleteAsync("api/LOC_City/" + cityId);

                return response;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion



        #region Select
        public async Task<List<LOC_City>> SelectAll()
        {
            try
            {
                var response = await _httpClient.GetFromJsonAsync<List<LOC_City>>("api/LOC_City/SelectAll");
                return response;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public async Task<List<LOC_City>> SelectByStateID(int cityId)
        {
            try
            {
                var response = await _httpClient.GetFromJsonAsync<List<LOC_City>>("api/LOC_City/" + cityId);
                return response;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        #endregion
    }
}
