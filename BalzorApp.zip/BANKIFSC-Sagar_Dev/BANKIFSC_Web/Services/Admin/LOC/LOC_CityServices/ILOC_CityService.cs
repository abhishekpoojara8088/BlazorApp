﻿using BANKIFSC_Shared.Entity.LOC;

namespace BANKIFSC_Web.Services.Admin.LOC.LOC_CityServices
{
    public interface ILOC_CityService
    {
        #region Insert
        Task<Task<HttpResponseMessage>> Insert(int stateId, LOC_City lOC_City);
        #endregion


        #region Update
        Task<HttpResponseMessage> Update(LOC_City lOC_City);
        #endregion


        #region Delete
        Task<HttpResponseMessage> Delete(int cityId);
        #endregion


        #region Select
        Task<List<LOC_City>> SelectAll();
        Task<List<LOC_City>> SelectByStateID(int cityId);
        #endregion
    }
}
