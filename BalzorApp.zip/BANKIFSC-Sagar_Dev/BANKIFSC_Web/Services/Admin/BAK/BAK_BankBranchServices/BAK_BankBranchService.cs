﻿using BANKIFSC_Shared.Entity.BAK;
using Newtonsoft.Json;
using System.Net.Http.Json;

namespace BANKIFSC_Web.Services.Admin.BAK.BAK_BankBranchServices
{
    public class BAK_BankBranchService : IBAK_BankBranchService
    {
        private readonly HttpClient _httpClient;

        public BAK_BankBranchService(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        #region Insert
        public async Task<int> Insert(BAK_BankBranch bAK_BankBranch)
        {
            try
            {
                var response = await _httpClient.PostAsJsonAsync("api/BAK_BankBranch", bAK_BankBranch);
                if (response.IsSuccessStatusCode)
                {
                    var branchId = response.Content.ReadAsStringAsync().Result;
                    return JsonConvert.DeserializeObject<int>(branchId);
                }
                else
                {
                    return 0;
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        //public async Task InsertImage(IFormFile file)
        //{
        //    try
        //    {
        //        await _httpClient.PostAsJsonAsync("api/BAK_Bank/insertImage", file);
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new Exception(ex.Message);
        //    }
        //}
        #endregion


        #region Update
        public async Task<int> Update(BAK_BankBranch bAK_BankBranch)
        {
            try
            {
                var response = await _httpClient.PutAsJsonAsync("api/BAK_BankBranch/", bAK_BankBranch);

                if (response.IsSuccessStatusCode)
                {
                    var branchId = response.Content.ReadAsStringAsync().Result;
                    return JsonConvert.DeserializeObject<int>(branchId);
                }
                else
                {
                    return 0;
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion


        #region Delete
        public async Task<HttpResponseMessage> Delete(int branchId)
        {
            try
            {
                var response = await _httpClient.DeleteAsync("api/BAK_BankBranch/" + branchId);

                return response;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        #endregion


        #region Select
        public async Task<List<BAK_BankBranch>> SelectAll()
        {
            try
            {
                var response = await _httpClient.GetFromJsonAsync<List<BAK_BankBranch>>("api/BAK_BankBranch/SelectAll");
                return response;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public async Task<List<BAK_BankBranch>> SelectByBranchID(int branchId)
        {
            try
            {
                var response = await _httpClient.GetFromJsonAsync<List<BAK_BankBranch>>("api/BAK_BankBranch/" + branchId);
                return response;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion

    }
}
