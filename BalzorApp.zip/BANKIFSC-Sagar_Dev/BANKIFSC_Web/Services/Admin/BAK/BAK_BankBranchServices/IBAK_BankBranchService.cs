﻿using BANKIFSC_Shared.Entity.BAK;

namespace BANKIFSC_Web.Services.Admin.BAK.BAK_BankBranchServices
{
    public interface IBAK_BankBranchService
    {
        #region Insert
        Task<int> Insert(BAK_BankBranch bAK_BankBranch);
        #endregion


        #region Update
        Task<int> Update(BAK_BankBranch bAK_BankBranch);
        #endregion


        #region Delete
        Task<HttpResponseMessage> Delete(int branchId);
        #endregion


        #region Select
        Task<List<BAK_BankBranch>> SelectAll();
        Task<List<BAK_BankBranch>> SelectByBranchID(int branchId);
        #endregion
    }
}
