﻿using Azure;
using BANKIFSC_Shared.Entity.BAK;
using BANKIFSC_Shared.Entity.LOC;
using Microsoft.AspNetCore.Http;
using Microsoft.SqlServer.Server;
using Newtonsoft.Json;
using System.Net.Http.Json;
using static System.Net.WebRequestMethods;

namespace BANKIFSC_Web.Services.Admin.BAK.BAK_BankServices
{
    public class BAK_BankService : IBAK_BankService
    {
        private readonly HttpClient _httpClient;
        
        public BAK_BankService(HttpClient httpClient)
        {
            _httpClient = httpClient;

        }

        #region Insert
        public async Task<int> Insert(BAK_Bank bAK_Bank)
        {
            try
            {
                var response = await _httpClient.PostAsJsonAsync("api/BAK_Bank", bAK_Bank);
                if (response.IsSuccessStatusCode)
                {
                    var bankId = response.Content.ReadAsStringAsync().Result;
                    return JsonConvert.DeserializeObject<int>(bankId);
                }
                else
                {
                    return 0;
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        //public async Task InsertImage(IFormFile file)
        //{
        //    try
        //    {
        //        await _httpClient.PostAsJsonAsync("api/BAK_Bank/insertImage", file);
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new Exception(ex.Message);
        //    }
        //}
        #endregion


        #region Update
        public async Task<int> Update(BAK_Bank bAK_Bank)
        {
            try
            {
                var response = await _httpClient.PutAsJsonAsync("api/BAK_Bank/", bAK_Bank);

                if (response.IsSuccessStatusCode)
                {
                    var bankId = response.Content.ReadAsStringAsync().Result;
                    return JsonConvert.DeserializeObject<int>(bankId);
                }
                else
                {
                    return 0;
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion


        #region Delete
        public async Task<HttpResponseMessage> Delete(int bankId)
        {
            try
            {
                var response = await _httpClient.DeleteAsync("api/BAK_Bank/" + bankId);

                return response;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
       
        #endregion


        #region Select
        public async Task<List<BAK_Bank>> SelectAll()
        {
            try
            {
                var response = await _httpClient.GetFromJsonAsync<List<BAK_Bank>>("api/BAK_Bank/SelectAll");
                return response;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public async Task<List<BAK_Bank>> SelectByBankID(int bankId)
        {
            try
            {
                var response = await _httpClient.GetFromJsonAsync<List<BAK_Bank>>("api/BAK_Bank/" + bankId);
                return response;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion
    }
}
