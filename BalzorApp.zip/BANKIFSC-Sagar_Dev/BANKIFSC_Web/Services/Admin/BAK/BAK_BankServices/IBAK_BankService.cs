﻿using BANKIFSC_Shared.Entity.BAK;
using Microsoft.AspNetCore.Http;

namespace BANKIFSC_Web.Services.Admin.BAK.BAK_BankServices
{
    public interface IBAK_BankService
    {
        #region Insert
        Task<int> Insert(BAK_Bank bAK_Bank);
       // Task InsertImage(IFormFile file);
        #endregion


        #region Update
        Task<int> Update(BAK_Bank bAK_Bank);
        #endregion


        #region Delete
        Task<HttpResponseMessage> Delete(int bankId);
        #endregion


        #region Select
        Task<List<BAK_Bank>> SelectAll();
        Task<List<BAK_Bank>> SelectByBankID(int bankId);
        #endregion
    }
}
