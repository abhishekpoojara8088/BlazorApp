
using BANKIFSC_DAL.IRepository;
using BANKIFSC_DAL.Repository;
using BANKIFSC_Web;
using Microsoft.AspNetCore.Components.Web;
using Microsoft.AspNetCore.Components.WebAssembly.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using MudBlazor.Services;
using System.Configuration;
using BANKIFSC_Web.Services.Admin.LOC.LOC_CountryServices;
using BANKIFSC_Web.Services.Admin.SEC.SEC_UserServices;
using BANKIFSC_Web.Services.Admin.LOC.LOC_StateServices;
using BANKIFSC_Web.Services.Admin.LOC.LOC_CityServices;
using BANKIFSC_Web.Services.Admin.BAK.BAK_BankServices;
using BANKIFSC_Web.Services.Admin.BAK.BAK_BankBranchServices;
using Blazored.SessionStorage;
using Microsoft.AspNetCore.Components.Authorization;
using BANKIFSC_Web.Authentication;

var builder = WebAssemblyHostBuilder.CreateDefault(args);
builder.RootComponents.Add<App>("#app");
builder.RootComponents.Add<HeadOutlet>("head::after");

builder.Services.AddMudBlazorDialog();
builder.Services.AddMudServices();
builder.Services.AddMudBlazorDialog();


builder.Services.AddScoped(sp => new HttpClient { BaseAddress = new Uri("https://localhost:7022/") });
builder.Services.AddBlazoredSessionStorage();
builder.Services.AddScoped<AuthenticationStateProvider, CustomAuthenticationStateProvider>();
builder.Services.AddAuthorizationCore();

builder.Services.AddScoped<ILOC_CountryService, LOC_CountryService>();
builder.Services.AddScoped<ILOC_CityService, LOC_CityService>();
builder.Services.AddScoped<ILOC_StateService, LOC_StateService>();
builder.Services.AddScoped<IBAK_BankService, BAK_BankService>();
builder.Services.AddScoped<IBAK_BankBranchService, BAK_BankBranchService>();
builder.Services.AddScoped<ISEC_UserService, SEC_UserService>();
//builder.Services.AddTransient<ILOC_CountryService, LOC_CountryService>();

await builder.Build().RunAsync();
